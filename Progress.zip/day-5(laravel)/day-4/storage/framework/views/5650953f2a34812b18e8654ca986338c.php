<h1>User Detils</h1>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>Name: <?php echo e($user->name); ?> </h3>
<h3>Email: <?php echo e($user->email); ?> </h3>
<h3>Age: <?php echo e($user->age); ?> </h3>
<h3>City: <?php echo e($user->city); ?> </h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\baboo.mehandro\Desktop\Progress\day-5(laravel)\day-4\resources\views/user.blade.php ENDPATH**/ ?>