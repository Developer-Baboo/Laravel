<h1>
    Home Page
</h1>
<?php /**PATH C:\Users\baboo.mehandro\Desktop\Progress\day-5(laravel)\day-4\resources\views/welcome.blade.php ENDPATH**/ ?>